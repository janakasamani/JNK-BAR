import connexion
import six

from swagger_server.models.add_drink_request import AddDrinkRequest  # noqa: E501
from swagger_server.models.edit_drink_request import EditDrinkRequest  # noqa: E501
from swagger_server.models.get_drink_response import GetDrinkResponse  # noqa: E501
from swagger_server.models.inline_response2004 import InlineResponse2004  # noqa: E501
from swagger_server.models.inline_response2005 import InlineResponse2005  # noqa: E501
from swagger_server import util


def add_drink(body=None):  # noqa: E501
    """add drink

    add the drink # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: InlineResponse2005
    """
    if connexion.request.is_json:
        body = AddDrinkRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def edit_drink(body=None):  # noqa: E501
    """edit drink

    edit drink # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: InlineResponse2004
    """
    if connexion.request.is_json:
        body = EditDrinkRequest.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def get_drink(name=None, ingredients=None):  # noqa: E501
    """get the drink

    get drink # noqa: E501

    :param name: 
    :type name: str
    :param ingredients: 
    :type ingredients: List[str]

    :rtype: GetDrinkResponse
    """
    return 'do some magic!'
